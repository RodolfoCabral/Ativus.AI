import os
from app import create_app, db
from models import User
from subscription_model import Subscription

app = create_app()

# Criar um contexto de aplicação para operações com o banco de dados
with app.app_context():
    # Criar todas as tabelas definidas nos modelos
    db.create_all()
    
    print('Tabelas criadas com sucesso!')
    
    # Verificar se já existem assinaturas
    subscription_count = Subscription.query.count()
    print(f'Número de assinaturas existentes: {subscription_count}')
