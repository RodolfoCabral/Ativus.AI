import os
from flask import Flask, send_from_directory, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user

# Inicialização das extensões
db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    
    # Configuração do banco de dados
    # Usar variável de ambiente do Heroku para PostgreSQL
    database_url = os.environ.get('HEROKU_POSTGRESQL_NAVY_URL', 
                                 'postgres://u9tl0n4jl7qbrq:p12422e041709cc69061990d960f13a979ad4aa954f6906d27c997fc4f80917e1@cee3ebbhveeoab.cluster-czrs8kj4isg7.us-east-1.rds.amazonaws.com:5432/de5jook8u1berl')
    
    # Corrigir o prefixo da URL para usar postgresql em vez de postgres
    if database_url.startswith('postgres:'):
        database_url = 'postgresql' + database_url[8:]
    
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'ativus-ai-secret-key-development')
    
    # Inicialização das extensões com o app
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    
    # Importar modelos
    from models import User
    from subscription_model import Subscription
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Configuração para servir arquivos estáticos
    @app.route('/')
    def index():
        return send_from_directory('static', 'index.html')
    
    @app.route('/signup')
    def signup_page():
        return send_from_directory('static', 'signup.html')
    
    @app.route('/static/<path:path>')
    def serve_static(path):
        return send_from_directory('static', path)
    
    # Rotas de autenticação
    @app.route('/api/login', methods=['POST'])
    def login():
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'message': 'Dados não fornecidos'}), 400
            
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'success': False, 'message': 'Email e senha são obrigatórios'}), 400
        
        user = User.query.filter_by(email=email).first()
        
        if not user or not user.check_password(password):
            return jsonify({'success': False, 'message': 'Email ou senha incorretos'}), 401
            
        # Se as verificações passarem, autenticar o usuário
        login_user(user)
        return jsonify({'success': True, 'message': 'Login realizado com sucesso', 'profile': user.profile})
    
    @app.route('/api/logout')
    @login_required
    def logout():
        logout_user()
        return jsonify({'success': True, 'message': 'Logout realizado com sucesso'})
    
    @app.route('/api/user')
    @login_required
    def get_user():
        return jsonify({
            'id': current_user.id,
            'email': current_user.email,
            'profile': current_user.profile
        })
    
    # Rota para o formulário de assinatura
    @app.route('/api/signup', methods=['POST'])
    def signup():
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'message': 'Dados não fornecidos'}), 400
            
        source = data.get('source')
        fullname = data.get('fullname')
        company = data.get('company')
        phone = data.get('phone')
        
        if not source or not fullname or not company or not phone:
            return jsonify({'success': False, 'message': 'Todos os campos são obrigatórios'}), 400
        
        # Criar nova assinatura
        new_subscription = Subscription(
            source=source,
            fullname=fullname,
            company=company,
            phone=phone
        )
        
        # Adicionar ao banco de dados
        db.session.add(new_subscription)
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Cadastro realizado com sucesso!',
            'subscription_id': new_subscription.id
        })
    
    return app
